package com.mera.absence;

import com.mera.employee.EmployeeEntity;
import lombok.Data;




@Data
public class Absence {
    private int id;
    private String absenceStart;
    private String absenceEnd;
    private boolean availability;
    private EmployeeEntity employee;
}
