package com.mera.assessment;

import com.mera.employee.EmployeeEntity;
import com.mera.projectManager.ProjectManagerEntity;
import com.mera.users.UsersEntity;
import lombok.Data;


import java.util.List;

@Data
public class Assessment {

    private int assessmentId;

    private String lastAssessment;

    private String nextAssessment;

    private String approvedAssessment;

    private String filledAssessment;

    private String productivity;

    private String status;

    private String statusChanged;

    private List<EmployeeEntity> employees;

    private ProjectManagerEntity projectManager;

    private UsersEntity users;
}
