package com.mera.assessment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AssessmentEndpoint {
    @Autowired
    AssessmentService assessmentService;

    @GetMapping(value = "/getLastAssessment")
    public AssessmentEntity getLastAssessment(@RequestParam int userID){
        return assessmentService.getLastAssessment(userID);
    }
}
