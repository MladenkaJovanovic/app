package com.mera.assessment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AssessmentServiceImpl implements AssessmentService {

    @Autowired
    AssessmentRepository assessmentRepository;

    @Override
    public AssessmentEntity getLastAssessment(int userId) {
        AssessmentEntity assessmentEntity = null;
        assessmentEntity = assessmentRepository.getLastAssessmentByIdTest(userId);
        return assessmentEntity;
    }
}
