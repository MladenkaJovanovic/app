package com.mera.client;

import com.mera.project.ProjectEntity;
import lombok.Data;


@Data
public class Client {

    private int clientId;

    private String name;

    private ProjectEntity project;
}
