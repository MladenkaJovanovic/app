package com.mera.client;

import com.mera.project.ProjectEntity;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table (name = "client")
public class ClientEntity {

    @Id @GeneratedValue
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;

    @OneToOne (fetch = FetchType.LAZY, optional=false)
    @JoinColumn (name = "fk_project")
    private ProjectEntity project;
}
