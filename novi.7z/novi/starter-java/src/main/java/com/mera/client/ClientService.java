package com.mera.client;

public interface ClientService {
}
