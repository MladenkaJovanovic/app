package com.mera.contact;

import com.mera.contact.otherContact.OtherContactEntity;
import com.mera.contact.phone.PhoneEntity;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "contact")
@Data
public class ContactEntity {
        @Id @GeneratedValue
        @Column(name = "id")
        private int id;
        @Column(name = "location")
        private String location;
        @Column(name = "email")
        private String email;
        @Column(name = "office_number")
        private String officeNumber;

        @OneToOne(fetch = FetchType.LAZY,optional=false)
        @JoinColumn(name = "fk_phone")
        private PhoneEntity phone;

        @OneToOne(fetch = FetchType.LAZY,optional=false)
        @JoinColumn(name = "fk_other_contact")
        private OtherContactEntity otherContact;
}
