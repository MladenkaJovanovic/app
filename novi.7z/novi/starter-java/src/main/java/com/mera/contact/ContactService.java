package com.mera.contact;

public interface ContactService {
}
