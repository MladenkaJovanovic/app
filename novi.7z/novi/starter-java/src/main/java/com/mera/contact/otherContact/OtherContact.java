package com.mera.contact.otherContact;

import lombok.Data;

@Data
public class OtherContact {
    private int id;
    private String icq;
    private String otherEmail;
    private String skype;
    private String skypeForBussiness;
    private String otherContacts;
}
