package com.mera.contact.otherContact;

public interface OtherContactService {
}
