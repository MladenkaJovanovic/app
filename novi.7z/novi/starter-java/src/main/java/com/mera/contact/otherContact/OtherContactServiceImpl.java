package com.mera.contact.otherContact;

import org.springframework.stereotype.Service;

@Service
public class OtherContactServiceImpl implements OtherContactService {
}
