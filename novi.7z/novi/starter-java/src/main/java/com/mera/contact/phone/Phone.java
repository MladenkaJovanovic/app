package com.mera.contact.phone;

import lombok.Data;

@Data
public class Phone {
    private int id;
    private Integer officePhone;
    private Integer outsidePhone;
    private Integer homePhone;
    private String esn;
}
