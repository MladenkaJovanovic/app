package com.mera.contact.phone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PhoneEndpoint {
    @Autowired
    PhoneService phoneService;
}
