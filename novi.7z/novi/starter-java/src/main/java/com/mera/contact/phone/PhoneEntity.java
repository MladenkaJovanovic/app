package com.mera.contact.phone;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "phone")
@Data
public class PhoneEntity {
    @Id @GeneratedValue
    @Column(name = "id")
    private int id;
    @Column(name = "office_phone")
    private Integer officePhone;
    @Column(name = "outside_phone")
    private Integer outsidePhone;
    @Column(name = "home_phone")
    private Integer homePhone;
    @Column(name = "esn")
    private String esn;
}
