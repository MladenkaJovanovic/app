package com.mera.contact.phone;

public interface PhoneService {
}
