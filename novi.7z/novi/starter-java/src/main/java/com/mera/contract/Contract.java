package com.mera.contract;

import com.mera.contract.probation.ProbationEntity;
import com.mera.employee.EmployeeEntity;
import lombok.Data;

@Data
public class Contract {

    private int contractId;

    private String insurance;

    private String typeOfEmployment;

    private String agreementNumber;

    private String agreementDate;

    private String timeAtJob;

    private String costCenter;

    private int hoursPerWeek;

    private EmployeeEntity employeeEntity;

    private ProbationEntity probation;
}
