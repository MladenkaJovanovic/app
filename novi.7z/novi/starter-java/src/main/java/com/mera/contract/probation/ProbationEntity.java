package com.mera.contract.probation;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Data
@Table (name = "PROBATION")
public class ProbationEntity {

    @Id @Column (name = "id")
    private int probationId;

    @Column (name = "begin_date")
    private LocalDate beginDate;

    @Column(name = "mentor")
    private String mentor;

    @Column (name = "registration_date")
    private LocalDate registrationDate;


}
