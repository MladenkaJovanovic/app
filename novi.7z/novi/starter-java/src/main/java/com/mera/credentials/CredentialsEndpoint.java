package com.mera.credentials;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CredentialsEndpoint {
    @Autowired
    CredentialsService credentialsService;
}
