package com.mera.credentials;

import com.mera.employee.EmployeeEntity;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "credentials")
@Data
public class CredentialsEntity {
    @Id @GeneratedValue
    @Column(name = "id")
    private int id;
    @Column(name = "username")
    private String username;
    @Column(name = "password")
    private String password;

    @OneToOne(fetch = FetchType.LAZY,optional=false)
    @JoinColumn(name = "fk_employee")
    private EmployeeEntity employee;
}
