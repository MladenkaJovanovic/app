package com.mera.credentials;

import org.springframework.stereotype.Service;

@Service
public class CredentialsServiceImpl implements CredentialsService {
}
