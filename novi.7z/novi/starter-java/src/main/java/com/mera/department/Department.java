package com.mera.department;

import com.mera.employee.EmployeeEntity;
import lombok.Data;

import java.util.List;

@Data
public class Department {

    private int departmentId;

    private String name;

    private String CFRDepartment;

    private String BUDepartment;

    private String reportsTo;

    private String program;

    private List<EmployeeEntity> listOfEmployees;
}
