package com.mera.employee;

public interface EmployeeService {
}
