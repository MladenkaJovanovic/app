package com.mera.personalInfo;

import com.mera.employee.EmployeeEntity;
import com.mera.personalInfo.passport.PassportEntity;
import lombok.Data;

@Data
public class PersonalInfo {
    private int id;
    private String jmbg;
    private String birthDate;
    private String citizenship;
    private String disability;
    private EmployeeEntity employee;
    private PassportEntity passport;
}
