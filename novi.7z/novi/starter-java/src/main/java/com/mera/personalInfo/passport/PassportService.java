package com.mera.personalInfo.passport;

public interface PassportService {
}
