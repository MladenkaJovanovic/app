package com.mera.presence;

public interface PresenceService {
}
