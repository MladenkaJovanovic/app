package com.mera.project;

import com.mera.employee.EmployeeEntity;
import com.mera.projectManager.ProjectManagerEntity;
import lombok.Data;

import java.util.List;

@Data
public class Project {

    private int projectId;

    private String name;

    private int teamMembers;

    private String startDate;

    private List<EmployeeEntity> listOfEmployees;

    private ProjectManagerEntity projectManager;
}
