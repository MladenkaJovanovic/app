package com.mera.project;

import com.mera.employee.EmployeeEntity;
import com.mera.projectManager.ProjectManagerEntity;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Table (name = "project")
@Data
public class ProjectEntity {

    @Id @GeneratedValue
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "team_members")
    private int teamMembers;

    @Column(name = "start_date")
    private String startDate;

    @ManyToMany(fetch = FetchType.LAZY)
    private List<EmployeeEntity> employees;

    @ManyToOne (fetch = FetchType.LAZY, optional=false)
    private ProjectManagerEntity projectManager;

}
