package com.mera.projectManager;

import com.mera.assessment.AssessmentEntity;
import com.mera.project.ProjectEntity;
import lombok.Data;

import java.util.List;

@Data
public class ProjectManager {

    private int projectManagerId;

    private String lastName;

    private String firstName;

    private List<ProjectEntity> listOfProjects;

    private List<AssessmentEntity> listOfAssessments;
}
