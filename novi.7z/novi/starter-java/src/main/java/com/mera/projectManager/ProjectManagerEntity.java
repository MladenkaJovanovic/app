package com.mera.projectManager;

import com.mera.assessment.AssessmentEntity;
import com.mera.project.ProjectEntity;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table (name = "project_manager")
public class ProjectManagerEntity {

    @Id @GeneratedValue
    @Column(name = "id")
    private int id;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "first_name")
    private String firstName;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "fk_employee")
    private List<ProjectEntity> projects;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "fk_assessment")
    private List<AssessmentEntity> listOfAssessments;

}
