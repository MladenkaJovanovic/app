package com.mera.role;

public interface RoleService {
}
