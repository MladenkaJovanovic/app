package com.mera.serviceStatus;

import com.mera.employee.EmployeeEntity;
import lombok.Data;

@Data
public class ServiceStatus {
    private int id;
    private String title;
    private String status;
    private String creationDate;
    private EmployeeEntity employee;
}
