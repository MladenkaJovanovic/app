package com.mera.serviceStatus;

import com.mera.employee.EmployeeEntity;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "service_status")
@Data
public class ServiceStatusEntity {
    @Id @GeneratedValue
    @Column(name = "id")
    private int id;
    @Column(name = "title")
    private String title;
    @Column(name = "status")
    private String status;
    @Column(name = "creation_date")
    private String creationDate;

    @OneToOne(fetch = FetchType.LAZY,optional=false)
    @JoinColumn(name = "fk_employee")
    private EmployeeEntity employee;
}
