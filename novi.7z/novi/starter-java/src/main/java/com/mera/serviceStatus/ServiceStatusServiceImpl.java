package com.mera.serviceStatus;

import org.springframework.stereotype.Service;

@Service
public class ServiceStatusServiceImpl implements ServiceStatusService {
}
