package com.mera.users;

import com.mera.role.RoleEntity;
import lombok.Data;


@Data
public class Users {
    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private String password;

    private RoleEntity role;
}
