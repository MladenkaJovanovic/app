package com.mera.users;

import com.mera.role.RoleEntity;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "users")
public class UsersEntity {

    @Id @GeneratedValue
    @Column(name = "id")
    private int id;
    @Column(name = "name")
    private String name;
    @Column(name = "last_name")
    private String lastName;
    @Column(name = "password")
    private String password;
    @Column(name = "email")
    private String email;

    @ManyToOne(fetch = FetchType.EAGER,optional=false)
    @JoinColumn(name = "fk_role")
    private RoleEntity role;
}
