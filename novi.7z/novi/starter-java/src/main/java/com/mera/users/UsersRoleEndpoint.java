package com.mera.users;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UsersRoleEndpoint {

    @Autowired
    UsersService userService;

//    @GetMapping(value = "/getUser")
    //case sensitive
//    @PreAuthorize("hasRole('ADMIN')")
//    public List<UserEntity> returnUser(@RequestParam String nameRole){
//        return userService.getUsersForProvidedRole(nameRole);
//    }
}
