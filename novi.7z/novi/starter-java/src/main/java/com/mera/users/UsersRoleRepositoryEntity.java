package com.mera.users;


import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "user_role")
@Data
public class UsersRoleRepositoryEntity {

    @Id
    @Column(name = "role_repository_id")
    private int id;

    @ManyToOne(fetch = FetchType.LAZY,optional=false)
    @JoinColumn(name = "fk_user", nullable = true, updatable = false)
    private UsersEntity user;

//    @ManyToOne(fetch = FetchType.EAGER,optional=false)
//    @JoinColumn(name = "fk_role", nullable = true, updatable = false)
//    private RoleEntity role;
}
