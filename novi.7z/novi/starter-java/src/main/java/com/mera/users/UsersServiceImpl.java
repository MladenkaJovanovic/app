package com.mera.users;

import org.springframework.stereotype.Service;

@Service//(value = "this")
public class UsersServiceImpl implements UsersService {

//    @Autowired
//    UserRoleRepository userRoleRepository;
//
// //   @Override
////    public List<UserEntity> getUsersForProvidedRole(String roleName) {
////        List<UserEntity> users = userRoleRepository.getRoleForUser(roleName);
////        return users;
//    }
}
