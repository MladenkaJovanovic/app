INSERT INTO USERS ( first_name, last_name, email, password) VALUES ( 'Strahinja', 'Petrovic', 'testmail@mera.com', 123456);
INSERT INTO USERS ( first_name, last_name, email, password) VALUES ( 'Veljko', 'Dimovic', 'testmail@mera.com', 123456);
INSERT INTO USERS ( first_name, last_name, email, password) VALUES ( 'Igor', 'Zivanovic', 'testmail@mera.com',123456);
INSERT INTO USERS ( first_name, last_name, email, password) VALUES ( 'Snezana', 'Radovic', 'testmail@mera.com', 123456);
INSERT INTO USERS ( first_name, last_name, email, password) VALUES ( 'Jelena', 'Tatarevic', 'testmail@mera.com', 123456);