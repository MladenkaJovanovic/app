insert into role(type) values ('HR');
insert into role(type) values ('GM');
insert into role(type) values ('DEVELOPER');
insert into role(type) values ('ADMIN');

