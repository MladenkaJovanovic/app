INSERT INTO CONTACT (location, email, office_number)  VALUES ('Belgrade', 'testmail@mera.com', 'AG022B');
INSERT INTO CONTACT (location, email, office_number)  VALUES ('Belgrade', 'testmail@mera.com', 'AG022B');
INSERT INTO CONTACT (location, email, office_number)  VALUES ('Belgrade', 'testmail@mera.com', 'AG022B');

INSERT INTO PHONE (office_phone, outside_phone, home_phone, esn) VALUES ('4589', '060123456', '011321456', 'testx1256');
INSERT INTO PHONE (office_phone, outside_phone, home_phone, esn) VALUES ('4532', '062123456', '011321456', 'testx1245');
INSERT INTO PHONE (office_phone, outside_phone, home_phone, esn) VALUES ('4556', '064123456', '011321456', 'testx1222');

INSERT INTO OTHER_CONTACT (other_email, icq, skype, skype_for_business, other_contacts) VALUES ('test@mail.com', '12345231', 'strahinja43', 'strahinjabussiness', 'korisnik1@yahoo.com');
INSERT INTO OTHER_CONTACT (other_email, icq, skype, skype_for_business, other_contacts) VALUES ('test@mail.com', '10989631', 'olivera43', 'oliverabussiness', 'korisnik2@yahoo.com');
INSERT INTO OTHER_CONTACT (other_email, icq, skype, skype_for_business, other_contacts) VALUES ('test@mail.com', '12645631', 'veljko43', 'veljkobussiness', 'korisnik3@yahoo.com')


