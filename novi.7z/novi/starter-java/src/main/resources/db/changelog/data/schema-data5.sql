insert into credentials(username, password) values ('strahinja', '123456');
insert into credentials(username, password) values ('olivera', '123456');
insert into credentials(username, password) values ('veljko', '123456');