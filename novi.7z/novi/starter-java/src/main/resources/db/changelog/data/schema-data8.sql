INSERT INTO SKILL (name, grade) VALUES ('Angular', '3');
INSERT INTO SKILL (name, grade) VALUES ('CSS', '1');
INSERT INTO SKILL (name, grade) VALUES ('HTML', '2');
