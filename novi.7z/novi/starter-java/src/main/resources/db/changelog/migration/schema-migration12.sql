CREATE TABLE DEPARTMENT
(
    id             serial primary key ,
    name           varchar(25),
    cfr_department varchar(25),
    bu_department  varchar(25),
    reports_to     varchar(30),
    program        varchar(40),
    fk_employee    int null
);