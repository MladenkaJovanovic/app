CREATE TABLE CONTRACT
(
    id                 serial primary key ,
    insurance          varchar(30),
    type_of_employment varchar(45)        not null,
    agreement_number   varchar(30)  not null,
    agreement_date     varchar(30),
    time_at_job        varchar(30),
    cost_center        varchar(100),
    hours_per_week     int,
    fk_employee        int                null,
    fk_probation       int                null
);