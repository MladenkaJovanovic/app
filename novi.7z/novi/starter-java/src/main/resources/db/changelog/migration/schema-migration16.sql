CREATE TABLE PROBATION
  (
      id                serial primary key ,
      begin_date        varchar(30),
      mentor            varchar(30),
      registration_date varchar(30)
  );