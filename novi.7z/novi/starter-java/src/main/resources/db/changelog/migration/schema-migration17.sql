CREATE TABLE PROJECT_MANAGER
(
    id            serial primary key ,
    last_name     varchar(30) not null,
    first_name    varchar(30) not null,
    fk_employee   int         null,
    fk_assessment int         null
);