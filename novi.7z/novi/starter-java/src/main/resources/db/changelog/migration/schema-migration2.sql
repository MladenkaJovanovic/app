CREATE TABLE ABSENCE
(
    id            serial primary key ,
    absence_start varchar(20),
    absence_end   varchar(20),
    availability  boolean,
    fk_employee   int null
);