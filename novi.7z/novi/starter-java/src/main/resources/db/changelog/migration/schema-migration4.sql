CREATE TABLE CONTACT
(
    id               serial primary key ,
    location         varchar(50),
    email            varchar(50),
    office_number    varchar(50),
    fk_phone         int null,
    fk_other_contact int null
);
CREATE TABLE PHONE
(
    id            serial primary key ,
    office_phone  varchar(50),
    outside_phone varchar(50),
    home_phone    varchar(50),
    esn           varchar(50)
);
CREATE TABLE OTHER_CONTACT
(
    id                 serial primary key ,
    other_email        varchar(50),
    icq                varchar(50),
    skype              varchar(50),
    skype_for_business varchar(50),
    other_contacts     varchar(50)
);