CREATE TABLE CREDENTIALS
(
    id          serial primary key ,
    username    varchar(50),
    password    varchar(50),
    fk_employee int null
);