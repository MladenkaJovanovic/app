CREATE TABLE SERVICE_STATUS
(
    id            serial primary key ,
    title         varchar(50),
    creation_date varchar(20),
    status        varchar(50),
    fk_employee   int null
);
