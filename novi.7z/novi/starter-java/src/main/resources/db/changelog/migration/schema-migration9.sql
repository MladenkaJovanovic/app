CREATE TABLE PROJECT
(
    id                 serial primary key ,
    name               varchar(100) not null,
    start_date         varchar(20),
    team_members       int,
    fk_employee        int         null,
    fk_project_manager int         null
);